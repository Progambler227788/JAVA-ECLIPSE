package strategypattern;

public interface PaymentStrategy {
	  String pay(double amount);
}
