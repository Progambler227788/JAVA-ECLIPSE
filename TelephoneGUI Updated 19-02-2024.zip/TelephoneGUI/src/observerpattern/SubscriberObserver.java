package observerpattern;

import users.*;
//SubscriberObserver class for observing changes in subscriber's account balance
class SubscriberObserver implements AccountObserver {
private Subscriber subscriber;

public SubscriberObserver(Subscriber subscriber) {
   this.subscriber = subscriber;
}

@Override
public void update(double newBalance) {
   System.out.println("Account balance updated for subscriber " + subscriber.getName() + ": " + newBalance);
}
}