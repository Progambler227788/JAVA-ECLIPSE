package observerpattern;

public interface AccountObserver {
	  void update(double newBalance);
}
